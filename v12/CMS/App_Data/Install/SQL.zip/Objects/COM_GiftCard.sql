SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[COM_GiftCard](
	[GiftCardID] [int] IDENTITY(1,1) NOT NULL,
	[GiftCardGuid] [uniqueidentifier] NOT NULL,
	[GiftCardDisplayName] [nvarchar](200) NOT NULL,
	[GiftCardName] [nvarchar](200) NOT NULL,
	[GiftCardDescription] [nvarchar](max) NULL,
	[GiftCardEnabled] [bit] NOT NULL,
	[GiftCardLastModified] [datetime2](7) NOT NULL,
	[GiftCardSiteID] [int] NOT NULL,
	[GiftCardValue] [decimal](18, 9) NOT NULL,
	[GiftCardMinimumOrderPrice] [decimal](18, 9) NULL,
	[GiftCardCartCondition] [nvarchar](max) NULL,
	[GiftCardValidFrom] [datetime2](7) NULL,
	[GiftCardValidTo] [datetime2](7) NULL,
	[GiftCardCustomerRestriction] [nvarchar](200) NULL,
	[GiftCardRoles] [nvarchar](400) NULL,
 CONSTRAINT [PK_COM_GiftCard] PRIMARY KEY CLUSTERED 
(
	[GiftCardID] ASC
)
)

GO
CREATE NONCLUSTERED INDEX [IX_COM_GiftCard_GiftCardSiteID] ON [dbo].[COM_GiftCard]
(
	[GiftCardSiteID] ASC
)
GO
ALTER TABLE [dbo].[COM_GiftCard] ADD  CONSTRAINT [DEFAULT_COM_GiftCard_GiftCardGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [GiftCardGuid]
GO
ALTER TABLE [dbo].[COM_GiftCard] ADD  CONSTRAINT [DEFAULT_COM_GiftCard_GiftCardDisplayName]  DEFAULT (N'') FOR [GiftCardDisplayName]
GO
ALTER TABLE [dbo].[COM_GiftCard] ADD  CONSTRAINT [DEFAULT_COM_GiftCard_GiftCardName]  DEFAULT (N'') FOR [GiftCardName]
GO
ALTER TABLE [dbo].[COM_GiftCard] ADD  CONSTRAINT [DEFAULT_COM_GiftCard_GiftCardEnabled]  DEFAULT ((1)) FOR [GiftCardEnabled]
GO
ALTER TABLE [dbo].[COM_GiftCard] ADD  CONSTRAINT [DEFAULT_COM_GiftCard_GiftCardLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [GiftCardLastModified]
GO
ALTER TABLE [dbo].[COM_GiftCard] ADD  CONSTRAINT [DEFAULT_COM_GiftCard_GiftCardSiteID]  DEFAULT ((0)) FOR [GiftCardSiteID]
GO
ALTER TABLE [dbo].[COM_GiftCard] ADD  CONSTRAINT [DEFAULT_COM_GiftCard_GiftCardValue]  DEFAULT ((0)) FOR [GiftCardValue]
GO
ALTER TABLE [dbo].[COM_GiftCard] ADD  CONSTRAINT [DEFAULT_COM_GiftCard_GiftCardCustomerRestriction]  DEFAULT (N'enum1') FOR [GiftCardCustomerRestriction]
GO
ALTER TABLE [dbo].[COM_GiftCard]  WITH CHECK ADD  CONSTRAINT [FK_COM_GiftCard_GiftCardSiteID_CMS_Site] FOREIGN KEY([GiftCardSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[COM_GiftCard] CHECK CONSTRAINT [FK_COM_GiftCard_GiftCardSiteID_CMS_Site]
GO
