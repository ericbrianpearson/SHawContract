SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OM_Score](
	[ScoreID] [int] IDENTITY(1,1) NOT NULL,
	[ScoreName] [nvarchar](200) NOT NULL,
	[ScoreDisplayName] [nvarchar](200) NOT NULL,
	[ScoreDescription] [nvarchar](max) NULL,
	[ScoreEnabled] [bit] NOT NULL,
	[ScoreEmailAtScore] [int] NULL,
	[ScoreNotificationEmail] [nvarchar](998) NULL,
	[ScoreLastModified] [datetime2](7) NOT NULL,
	[ScoreGUID] [uniqueidentifier] NOT NULL,
	[ScoreStatus] [int] NULL,
	[ScoreScheduledTaskID] [int] NULL,
	[ScoreBelongsToPersona] [bit] NOT NULL,
 CONSTRAINT [PK_OM_Score] PRIMARY KEY CLUSTERED 
(
	[ScoreID] ASC
)
)

GO
ALTER TABLE [dbo].[OM_Score] ADD  CONSTRAINT [DEFAULT_OM_Score_ScoreBelongsToPersona]  DEFAULT ((0)) FOR [ScoreBelongsToPersona]
GO
