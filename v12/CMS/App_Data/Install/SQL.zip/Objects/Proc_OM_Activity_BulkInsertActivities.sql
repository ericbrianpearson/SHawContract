SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Proc_OM_Activity_BulkInsertActivities]
@Activities Type_OM_ActivityTable readonly,
@LastID int OUT
AS
BEGIN
-- SET NOCOUNT ON added to prevent extra result sets from
		-- interfering with SELECT statements.
	SET NOCOUNT ON;

	INSERT INTO [OM_Activity]
	SELECT [ActivityContactID]
      ,[ActivityCreated]
      ,[ActivityType]
      ,[ActivityItemID]
      ,[ActivityItemDetailID]
      ,[ActivityValue]
      ,[ActivityURL]
      ,[ActivityTitle]
      ,[ActivitySiteID]
      ,[ActivityComment]
      ,[ActivityCampaign]
      ,[ActivityURLReferrer]
      ,[ActivityCulture]
      ,[ActivityNodeID]
      ,[ActivityUTMSource]
      ,[ActivityABVariantName]
      ,[ActivityMVTCombinationName]
      ,[ActivityURLHash]
	  ,[ActivityUTMContent]
	 FROM @Activities

	SET @LastID = SCOPE_IDENTITY()
END


GO
